#include <stdio.h>
#include <math.h>
#define Eps 1e-4
#define BottomLimit 0
#define TopLimit 5


using namespace std;

double StartFunction(double x){
    return ( -0.964*exp( -0.158 * pow((x + 0.747),2) )+ 0.575);
}

void MethodRightRectangle(){
    double Height,Square1,Square2;
    int Numb = 1;

    FILE * file;
    file = fopen("output.txt", "w");
    fprintf(file, "Функция f = 1 / (5 - x)\nПределы интегрирования: BottomLimit = %d, TopLimit = %d\nE = %lf \nПодсчет площади методом правых прямоугольников...\n", BottomLimit, TopLimit, Eps);
    do{
        Height=(double)(TopLimit-BottomLimit)/Numb;
        Square1=0;

        for(int i=0; i < Numb; i++)
        {
            Square1+=Height*StartFunction(BottomLimit+(i+1)*Height);
        }

        Numb*=2;
        Square2=0;
        Height=(double)(TopLimit-BottomLimit)/Numb;

        for(int i=0;i < Numb;i++)
        {
            Square2+=Height*StartFunction(BottomLimit+(i+1)*Height);
        }
        fprintf(file,"Square1-Square2 = %lf\tSquare1 = %lf\tSquare2 = %lf\tHeight = %lf\tn = %d\n",Square1-Square2, Square1, Square2, Height, Numb);
    }while( (fabs(Square1-Square2))>Eps );


    fprintf(file,"Интеграл равен = %lf\n\n\n", Square2);
    fclose(file);
};

void methodSimpson(){
    double Height,Square1,Square2;
    int Numb = 2;

    FILE *file;
    file = fopen("output.txt", "a");
    fprintf(file, "Функция f = sin(x) + 2\nПределы интегрирования: BottomLimit = %d, TopLimit = %d\nE = %lf \nПодсчет площади методом Симпсона...\n", BottomLimit, TopLimit, Eps);

    do{
        Height=(double)(TopLimit-BottomLimit)/(2*Numb);
        Square1=0;

        for(int i=0; i < Numb; i++)
        {
            Square1+= (Height/3)*(StartFunction(BottomLimit+(2*i*Height)) + 4*(StartFunction(BottomLimit+Height+(2*i*Height))) + StartFunction(BottomLimit+(2*Height) + (2*i*Height)));
        }

        Numb*=2;
        Square2=0;
        Height=(double)(TopLimit-BottomLimit)/(2*Numb);

        for(int i=0;i<Numb;i++)
        {
            Square2+=(Height/3)*(StartFunction(BottomLimit+(2*i*Height)) + 4*(StartFunction(BottomLimit+Height+(2*i*Height))) + StartFunction(BottomLimit+(2*Height) + (2*i*Height)));
        }
        fprintf(file,"Square1-Square2 = %lf\tSquare1 = %lf\tSquare2 = %lf\tHeight = %lf\tn = %d\n",Square1-Square2, Square1, Square2, Height, Numb);
    }while( (fabs(Square1-Square2))>Eps );



    fprintf(file,"Интеграл равен = %lf\n", Square2);
    fclose(file);
};

int main(){
    MethodRightRectangle();
    methodSimpson();
    return 0;
}