let dx: number = 0.1
let x0: number = 1.9
let y0: number = 0.6
let xMax: number = 3.3
let objEiler = {}
let objEilerMod = {}
let objDiv1RK = {}
let objDiv10RK = {}

let objDiv1 = {}
let objDiv2 = {}
let objDiv4 = {}
let objDiv6 = {}
let objDiv8 = {}

function DifFunc(x: number,y : number){
    return ( -0.964 + 0.575*x - 0.747*Math.pow(x,2) - 0.158*y -0.068 * x * y )
}


function Eiler(): void{
    let x: number = x0
    let y: number = y0
    let obj = objEiler
    for (let i:number = x0 ; i <= xMax ; i+= dx) {
        obj[x.toFixed(7)] = y
        let k1 = dx * DifFunc(x,y)
        x = x + dx
        y = y + k1
    }
    obj[x.toFixed(7)] = y
    for(let key in obj){
        $(".EilerTable").append("<tr> <th>"+key+"</th> <td>"+ obj[key]+"</td></tr>  ")
    }

}


function ModEiler(): void{
    let x: number = x0
    let y: number = y0
    let obj = objEilerMod

    for (let i:number = x0 ; i <= xMax ; i+= dx) {
        obj[x.toFixed(7)] = y
        let k1 = dx/2 * DifFunc(x, y)
        let k2 = dx * DifFunc(x + dx/2, y + k1)
        x = x + dx
        y = y + k2
    }
    obj[x.toFixed(7)] = y
    for(let key in obj){
        $(".ModEilerTable").append("<tr> <th>"+key+"</th> <td>"+ obj[key]+"</td></tr>  ")
    }

}

function EilerKoshi(k: number): void{
    let dxLocal: number = k
    let x: number = x0
    let y: number = y0
    let obj = SwitchObjEK(k)

    for (let i:number = x0 ; i <= xMax ; i+= dxLocal) {
        obj[x.toFixed(7)] = y
        let k1 = dxLocal * DifFunc(x, y)
        let k2 = dxLocal * DifFunc(x + dxLocal, y + k1)
        x = x + dxLocal
        y = y + 0.5*(k1+k2)
    }
    obj[x.toFixed(7)] = y
    console.log("метод Эйлера-Коши с шагом: " + dxLocal)
    console.log(obj)

}

function RungeKutt4(k:number): void{
    let dxLocal: number = k
    let x: number = x0
    let y: number = y0
    let obj = SwitchObjRK(k)

    for (let i:number = x0 ; i <= xMax ; i+= dxLocal) {
        obj[x.toFixed(7)] = y
        let k1 = dxLocal * DifFunc(x, y)
        let k2 = dxLocal * DifFunc(x + dxLocal/2, y + k1/2)
        let k3 = dxLocal * DifFunc(x + dxLocal/2,  y + k2/2)
        let k4 = dxLocal * DifFunc(x + dxLocal, y + k3)
        x = x + dxLocal
        y = y + 1/6 * (k1 + 2 * k2 + 2 * k3 + k4)
    }
    obj[x.toFixed(7)] = y
    delete obj["3.3100000"]
    if(dxLocal == dx){
        for(let key in obj){
            $(".RungeKuttTable1").append("<tr> <th>"+key+"</th> <td>"+ obj[key]+"</td></tr>")
        }
    }else if(dxLocal == dx/10){
        for(let key in obj){
            $(".RungeKuttTable2").append("<tr> <th>"+key+"</th> <td>"+ obj[key]+"</td></tr>")
        }
    }

}

function SwitchObjEK(k: number): any{
    switch (k) {
        case dx:
            return objDiv1
        case dx/2:
            return objDiv2
        case dx/4:
            return objDiv4
        case dx/6:
            return objDiv6
        case dx/8:
            return objDiv8

        default:
            break;
    }
}
function SwitchObjRK(k: number): any{
    switch (k) {
        case dx:
            return objDiv1RK
        case dx/10:
            return objDiv10RK
        default:
            break;
    }
}


Eiler()
ModEiler()
RungeKutt4(dx)
RungeKutt4(dx/10)

EilerKoshi(dx)
EilerKoshi(dx/2)
EilerKoshi(dx/4)
EilerKoshi(dx/6)
EilerKoshi(dx/8)


// objDiv10RK - самый точный

function GetError(): number[]{
    function randomColor(){
        return "#" + Math.floor(Math.random() * 9).toString() + Math.floor(Math.random() * 9).toString() + Math.floor(Math.random() * 9).toString() + Math.floor(Math.random() * 9).toString() + Math.floor(Math.random() * 9).toString() + Math.floor(Math.random() * 9).toString()
    }
    let Errarr = []
    let text: string = "3.3000000"
    Errarr.push(["Э", Math.abs(objDiv10RK[text] - objEiler[text]), randomColor()])
    Errarr.push( ["МЭ", Math.abs(objDiv10RK[text] - objEilerMod[text]), randomColor()] )
    Errarr.push( ["ЭК", Math.abs(objDiv10RK[text] - objDiv1[text]), randomColor()] )
    Errarr.push( ["РК", Math.abs(objDiv10RK[text] - objDiv1RK[text]), randomColor()] )
    Errarr.push( ["dx/2", Math.abs(objDiv10RK[text] - objDiv2[text]), randomColor()] )
    Errarr.push( ["dx/4", Math.abs(objDiv10RK[text] - objDiv4[text]), randomColor()] )
    Errarr.push( ["dx/6", Math.abs(objDiv10RK[text] - objDiv6[text]), randomColor()] )
    Errarr.push( ["dx/8", Math.abs(objDiv10RK[text] - objDiv8[text]), randomColor()] )

    return(Errarr)
}


let arrNumbs: number[] = []

function setArrP4(numbsOfArr: string[]): void{
    for (let i = 0; i < numbsOfArr.length; i++) {
        let arrtmp: number[] = [parseFloat(numbsOfArr[i])]
        arrtmp.push(objEiler[numbsOfArr[i]])
        arrtmp.push(objEilerMod[numbsOfArr[i]])
        arrtmp.push(objDiv1RK[numbsOfArr[i]])
        arrtmp.push(objDiv10RK[numbsOfArr[i]])

        arrNumbs = [...arrNumbs , arrtmp]
    }
}
function setArrP6(numbsOfArr: string[]): void{
    for (let i = 0; i < numbsOfArr.length; i++) {
        let arrtmp: number[] = [parseFloat(numbsOfArr[i])]
        arrtmp.push(objDiv2[numbsOfArr[i]])
        arrtmp.push(objDiv4[numbsOfArr[i]])
        arrtmp.push(objDiv6[numbsOfArr[i]])
        arrtmp.push(objDiv8[numbsOfArr[i]])
        arrtmp.push(objDiv10RK[numbsOfArr[i]])

        arrNumbs = [...arrNumbs , arrtmp]
    }
}
let numbsOfArr: string[] = ["2.9000000" ,"3.0000000" ,"3.1000000", "3.2000000", "3.3000000"]
setArrP4(numbsOfArr)




let arrErr = [["Метод", "Величина ошибки", { role: "style" } ]]
arrErr.push(...GetError())
console.log("Значения ошибки")
console.log(arrErr)



google.charts.load('current', { 'packages': ['line'] });
google.charts.setOnLoadCallback(drawChartLine);

function drawChartLine() {
    let data = new google.visualization.DataTable();
    data.addColumn('number', 'X');
    data.addColumn('number', 'Эйлера');
    data.addColumn('number', 'Модифицированный Эйлера');
    data.addColumn('number', 'Рунге-Кутты');
    data.addColumn('number', 'Рунге-Кутты с шагом 0.01');
    data.addRows(arrNumbs);
    let options = {
        chart: {
            title: 'График решения дифференциального уравнения',
        },
        hAxis: { title: "X" },
        vAxis: { title: "Y" }
    };
    let chart = new google.charts.Line(document.getElementById('chartp4'));
    chart.draw(data, google.charts.Line.convertOptions(options));
}
google.charts.setOnLoadCallback(drawChartLineP6);
function drawChartLineP6() {
    let data = new google.visualization.DataTable();
    data.addColumn('number', 'X');
    data.addColumn('number', 'Эйлера-Коши с точностью 0.05');
    data.addColumn('number', 'Эйлера-Коши с точностью 0.025');
    data.addColumn('number', 'Эйлера-Коши с точностью 0.01666');
    data.addColumn('number', 'Эйлера-Коши с точностью 0.0125');
    data.addColumn('number', 'Рунге-Кутты с шагом 0.01');
    arrNumbs = []
    setArrP6(numbsOfArr)
    data.addRows(arrNumbs);
    let options = {
        chart: {
            title: 'График решения дифференциального уравнения с уменьшенными шагами интегрирования',
        },
        hAxis: { title: "X" },
        vAxis: { title: "Y" }
    };
    let chart = new google.charts.Line(document.getElementById('chartp7'));
    chart.draw(data, google.charts.Line.convertOptions(options));
}


google.charts.setOnLoadCallback(drawChartLineAbsLen);
function drawChartLineAbsLen() {
    let data = new google.visualization.DataTable();
    data.addColumn('number', 'X');
    data.addColumn('number', 'ЭК');
    data.addRows([
        [Object.keys(objDiv1).length , arrErr[3][1]],
        [Object.keys(objDiv2).length , arrErr[5][1]],
        [Object.keys(objDiv4).length , arrErr[6][1]],
        [Object.keys(objDiv6).length , arrErr[7][1]],
        [Object.keys(objDiv8).length , arrErr[8][1]],
    ]);
    let options = {
        chart: {
            title: 'График зависимости абсолютной ошибки от количества итераций на примере метода Эйлера-Коши',

        },
        hAxis: { title: "X" },
        vAxis: { title: "Y" },
        hAxis: { title: "X" },
        vAxis: { title: "Y" }
    };
    let chart = new google.charts.Line(document.getElementById('chartErrAbsLen'));
    chart.draw(data, google.charts.Line.convertOptions(options));
}



google.charts.load("current", { packages: ['corechart'] });
google.charts.setOnLoadCallback(drawChartColumn);

function drawChartColumn() {
    let data = google.visualization.arrayToDataTable(arrErr);

    let view = new google.visualization.DataView(data);
    view.setColumns([0, 1,
        {
            calc: "stringify",
            sourceColumn: 1,
            type: "string",
            role: "annotation"
        },
        2]);

    let options = {
        title: "Зависимость метода от точности",

        bar: { groupWidth: "95%" },
        legend: { position: "none" },
    };
    let chart = new google.visualization.ColumnChart(document.getElementById("chartErr"));
    chart.draw(view, options);
}
